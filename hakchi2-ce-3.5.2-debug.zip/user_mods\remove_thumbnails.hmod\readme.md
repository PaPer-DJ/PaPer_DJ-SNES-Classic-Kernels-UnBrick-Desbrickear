------------------------
Name: No-thumbnails Hack
Creator: Cluster
Category: UI
------------------------
This module removes thumbnails at the bottom of the screen.
