Copy your IPS patches here, and hakchi2 will look here when adding games. If it finds a filename that starts with the ROM CRC32 checksum, hakchi2 will ask you to apply this patch.
